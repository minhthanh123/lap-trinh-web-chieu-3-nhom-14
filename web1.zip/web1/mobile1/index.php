<?php 
spl_autoload_register(function($class_name){
	require './app/Models/' . $class_name . '.php';
});
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Login</title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>
	<?php
	session_start();
		if (isset($_POST['submit'])) {

				$username = $_POST['username'];
				$password = $_POST['password'];
		
			if (User::login($username, $password)) 
			{
				$_SESSION['username'] = $username;
				if(!empty($_POST["remember"]))   
				   {  
				    setcookie ("member_login",$username,time()+ 3600);  
				    setcookie ("member_password",$password,time()+ 3600);
				   }  
				else  
				   {  
					    if(isset($_COOKIE["member_login"]))   
					    {  
					     setcookie ("member_login","");  
					    }  
					    if(isset($_COOKIE["member_password"]))   
					    {  
					     setcookie ("member_password","");  
					    }  
				   }  
				header("location:../mobile1/admin/index.php");
			} 
			else 
			{
				echo  "<script>
						alert('Bạn nhập sai tài khoản hoặc mật khẩu. Vui lòng nhập lại !');
						</script>";
				header("location:../mobile1/index.php");
			}
			
		} else {

		
	?>
	<div class="container">
		
		<form action="index.php" method="POST" role="form">
			
			<legend>Login</legend>
			<div class="form-group">
				<label for="username">Username</label>
				<input type="text" class="form-control" id="username" name="username" placeholder="Input username " value="<?php if(isset($_COOKIE["member_login"])) { echo $_COOKIE["member_login"]; } ?>">
			</div>

			<div class="form-group">
				<label for="password">Password</label>
				<input type="password" class="form-control" id="password" name="password" placeholder="Input password" value="<?php if(isset($_COOKIE["member_password"])) { echo $_COOKIE["member_password"]; } ?>" >
			</div>
			
			<button type="submit" name="submit" value="userLogin" class="btn btn-primary">Login</button>
		</form>
	</div>
	<?php } ?>

<?php 
 ?>

</body>
</html>