<?php
	//require "../app/config.php";
	require "../app/db.php";
	$db = new db();
	if (isset($_POST['add']))
	{
		$name = $_POST['name'];
		$type_id = $_POST['type_id'];
		$manu_id = $_POST['manu_id'];
		$description = $_POST['description'];
		$price = $_POST['price'];
		$feature = $_POST['feature'];
		if (isset($_FILES['fileUpload']))
		{
			$file_name = $_FILES['fileUpload']['name'];
			$image = $_FILES['fileUpload']['name'];
			$file_tmp = $_FILES['fileUpload']['tmp_name'];
		}
		echo $name;
		echo $manu_id;
		echo $price;
		echo $image;
		$add = $db->addProduct($name, $manu_id, $price, $image, $description, $feature);
		var_dump($add);
		if (isset($add))
		{
			move_uploaded_file($file_tmp,"public/images/".$file_name);
			header('location:index.php');
		}
	}
?>