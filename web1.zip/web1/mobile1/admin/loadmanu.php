<?php 
	require "../app/db.php";
	$db = new db();
	$type_id = $_GET['type_id'];
	$getManu = $db->getManuByProtype($type_id);
	foreach ($getManu as $row) {
		?>
		<option value="<?php echo $row['manu_id'] ?>"> <?php echo $row['manu_name'] ?></option>	
		<?php
	}
		?>