<?php
session_start();
session_destroy();
header("location:http://localhost:82/baitap/1/login.php");
