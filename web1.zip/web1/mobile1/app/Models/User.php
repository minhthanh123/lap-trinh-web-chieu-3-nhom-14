<?php
/**
* 
*/
class User
{
	private $username;
	private $password;
	private $lastName;
	private $firstName;

	function __construct($username, $password, $firstName, $lastName)
	{
		$this->username = $username;
		$this->password = password_hash($password, PASSWORD_DEFAULT);
		$this->lastName = $lastName;
		$this->firstName = $firstName;
	}

	public function getUsername() {
		return $this->username;
	}

	public function getFullname() {
		return $this->firstName . " " . $this->lastName;
	}

	public static function login($username, $password) {
		//$hash = password_hash(123456, PASSWORD_DEFAULT);
		if ($username == "admin" && $password = admin)// password_verify($password, $hash) )
		 {
			return true;
		}
		return false;
	}
}